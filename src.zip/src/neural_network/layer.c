#include "layer.h"

Layer* createLayer(LayerConfig* config) {
    Layer* layer = malloc(sizeof(Layer));

    layer->neuronCount = config->neuronCount;

    // If 2 subsequent layers have X and Y neurons, then the number of weights is X*Y
    layer->weights = createMatrix(config->neuronCount, config->inputSize);

    initialize_weights_he(config->inputSize, config->neuronCount, layer->weights);

    layer->biases = createVector(config->neuronCount);
    initializeVectorWithRandomValuesInRange(layer->biases, -0.5, 0.5);

    layer->biasGradients = createVector(config->neuronCount);

    layer->weightedSums = createVector(config->neuronCount);
    layer->output = createVector(config->neuronCount);

    layer->activationFunction = config->activationFunction;
    
    layer->gradients = createMatrix(layer->weights->rows, layer->weights->columns);
    layer->dLoss_dWeightedSums = createVector(layer->neuronCount);

    if(config->willUseMomentum == 1 || config->optimizer == ADAM){
        layer->weightMomentums = createMatrix(layer->weights->rows, layer->weights->columns);
        fillMatrix(layer->weightMomentums, 0.0f);
        layer->biasMomentums = createVector(layer->biases->size);
        fillVector(layer->biasMomentums, 0.0f);
    }


    if(config->optimizer == ADAGRAD || config->optimizer == RMS_PROP || config->optimizer == ADAM) {
        layer->weightCache = createMatrix(layer->weights->rows, layer->weights->columns);
        fillMatrix(layer->weightCache, 0.0f);
        layer->biasCache = createVector(layer->biases->size);
        fillVector(layer->biasCache, 0.0f);
    }

    return layer;
}

void deleteLayer(Layer* layer) {
    if (layer == NULL) {
        return;
    }

    // Free the resources allocated for the layer
    freeMatrix(layer->input);
    freeMatrix(layer->weights);
    freeVector(layer->biases);
    freeVector(layer->output);
    freeVector(layer->error);
    freeMatrix(layer->gradients);
    freeVector(layer->biasGradients);
    freeVector(layer->dLoss_dWeightedSums);
    freeMatrix(layer->weightMomentums);
    freeVector(layer->biasMomentums);
    freeMatrix(layer->weightCache);
    freeVector(layer->biasCache);

    // Free the layer itself
    free(layer);
}

void initialize_weights_he(int inputNeuronCount, int outputNeuronCount, Matrix* weights) {
    // Calculate limit
    double limit = sqrt(2.0 / (double)inputNeuronCount);

    // Initialize weights
    for(int i = 0; i < outputNeuronCount; i++) {
        for(int j = 0; j < inputNeuronCount; j++) {
            // Generate a random number between -limit and limit
            double rand_num = (double)rand() / RAND_MAX; // This generates a random number between 0 and 1
            rand_num = rand_num * 2 * limit - limit; // This shifts the range to [-limit, limit]
            weights->data[i]->elements[j] = rand_num;
        }
    }
}
