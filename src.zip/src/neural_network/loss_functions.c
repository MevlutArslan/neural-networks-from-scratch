#include "loss_functions.h"

double meanSquaredError(Matrix* outputs, Matrix* targets) {
    double mse = 0.0;

    for (int i = 0; i < outputs->rows; i++) {
        Vector* output = outputs->data[i];
        Vector* target = targets->data[i];

        double difference = target->elements[0] - output->elements[0]; // assuming both vectors have size 1
        mse += (difference * difference) / 2;

        #ifdef DEBUG
            char* outputVectorStr = vectorToString(output);
            char* targetVectorStr = vectorToString(target);
            
            log_debug(
                "MSE Input & Intermediate Output: \n"
                "Output Vector: %s \n"
                "Target Vector: %s \n"
                "Squared Difference: %f \n", 
                outputVectorStr, 
                targetVectorStr, 
                difference * difference / 2
            );
            
            free(outputVectorStr);
            free(targetVectorStr);
        #endif
    }

    mse /= (double)outputs->rows;

    #ifdef DEBUG
        log_debug("Final MSE: %f \n", mse);
    #endif

    return mse;
}


double meanSquaredErrorDerivative(double target, double predicted) {
    return -1 * (target - predicted);
}

/*
    Should be used when both target and prediction are one hot encoded vectors!
    The formula for Categorical Cross Entropy simplifies to: 
        -1 * log(prediction_vector[index of the target category in the target vector])
*/
double categoricalCrossEntropyPerInput(Vector* target, Vector* output) {
    double loss = -1 * target->elements[argMax(target)] * log(output->elements[argMax(output)]);
    #ifdef DEBUG
        char* targetVectorStr = vectorToString(target);
        char* outputVectorStr = vectorToString(output);

        // log the inputs and the output
        log_debug(
            "Cross Entropy Inputs & Output: \n"
            "\t\t\t\tTarget Vector: %s \n"
            "\t\t\t\tOutput Vector: %s \n"
            "\t\t\t\tCross Entropy: %f \n", 
            targetVectorStr, 
            outputVectorStr, 
            loss
        );

        free(targetVectorStr);
        free(outputVectorStr);
    #endif
    // we don't care about the cases where target_i is 0 as 0 * log(output_i) will return 0 nonetheless
    return loss;
}

/* 
    * The categorical cross-entropy loss is exclusively used in multi-class classification tasks.
*/
double categoricalCrossEntropyLoss(Matrix* targetOutputs, Matrix* outputs) {
    double sum = 0.0f;
    // todo: change this back to output.rows
    for(int i = 0; i < 20; i++) {
        sum += categoricalCrossEntropyPerInput(targetOutputs->data[i], outputs->data[i]);
    }

    #ifdef DEBUG
        // todo: change this back to output.rows
        log_info("Called multiClassCrossEntropyLoss & returned: %f \n", sum / 20);
    #endif
    // todo: change this back to output.rows
    return sum / 20;
}

/*
    * Derivative of sum equals sum of the derivatives
    * Derivative of the logarithmic function is the reciprocal of its parameter, multiplied by the partial derivative of this parameter.
      1/prediction_vector[index] * d_prediction_vector[index]
*/
Vector* categoricalCrossEntropyLossDerivative(Vector* target, Vector* predictions) {
    Vector* lossGrads = createVector(predictions->size);
    for(int i = 0; i < predictions->size; i++) {
        double target_i = target->elements[i];
        double prediction_i = predictions->elements[i];
        lossGrads->elements[i] = -1 * (target_i / prediction_i + 1e-7);
    }

    #ifdef DEBUG
        char* targetVectorStr = vectorToString(target);
        char* outputVectorStr = vectorToString(predictions);
        char* lossGradStr = vectorToString(lossGrads);
        log_debug(
            "Cross Entropy Derivative Inputs & Output: \n"
            "\t\t\t\tTarget Vector: %s \n"
            "\t\t\t\tOutput Vector: %s \n"
            "\t\t\t\tLoss Grads: %s \n", 
            targetVectorStr, 
            outputVectorStr, 
            lossGradStr
        );
    #endif

    return lossGrads;
}
